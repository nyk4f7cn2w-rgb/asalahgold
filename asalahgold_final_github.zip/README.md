# ASALAH GOLD Official Website

ارفع جميع الملفات إلى مستودع GitHub ثم فعّل GitHub Pages من Settings > Pages > Deploy from branch > main > /(root).
